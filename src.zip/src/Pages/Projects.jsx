import { Box, Center, Heading, Show } from "@chakra-ui/react";
import React from "react";
import {
  MediumProjectCard,
  ProjectCards,
} from "../components/Projects/ProjectCards";

import healthPrime_1 from "../images/healthPrime_1.png";
import healthPrime_2 from "../images/healthPrime_2.png";
import healthPrime_3 from "../images/healthPrime_3.png";
import healthPrime_4 from "../images/healthPrime_4.png";
import healthPrime_5 from "../images/healthPrime_5.png";

const Projects = () => {
  const HealthPrime = [
    healthPrime_1,
    healthPrime_2,
    healthPrime_3,
    healthPrime_4,
    healthPrime_5,
  ];
  return (
    <Box
      pl={{
        base: "5",
        sm: "5",
        md: "5",
        lg: "10",
        xl: "10",
        "2xl": "10",
      }}
      pr={{
        base: "5",
        sm: "5",
        md: "5",
        lg: "10",
        xl: "10",
        "2xl": "10",
      }}
      id="projects"
    >
      <Center>
        <Heading mb={"40px"}>Projects</Heading>
      </Center>

      <ProjectCards
        direction={"row-reverse"}
        deployedLink={"https://roasted-geese-6392-xh5g.vercel.app/"}
        image={HealthPrime}
        title={"Health Prime"}
        subTitle={"1mg Clone"}
        GithubLink={"https://github.com/Varun8177/Tata-1mg-clone"}
        features={[
          "Sign up or log in to add items to your cart and complete purchases",
          "Each product has a dedicated page with a detailed description",
          "View your cart details from the navbar section at any time",
          "Sort, search, and filter to easily find the products you're looking for",
        ]}
        description={
          "Health Prime is an online platform that offers a wide range of healthcare products and medicines to users. With its user-friendly interface and competitive pricing, Health Prime makes it easy for users to find and purchase the products they need. "
        }
        techStack={["Next.js", "Chakra UI", "FireBase", "Redux"]}
      />
      <Show breakpoint="(max-width: 993px)">
        <MediumProjectCard
          image={HealthPrime}
          deployedLink={"https://roasted-geese-6392-xh5g.vercel.app/"}
          GithubLink={"https://github.com/Varun8177/Tata-1mg-clone"}
          title={"Health Prime"}
          subTitle={"1mg Clone"}
          description={
            "Health Prime is an online platform that offers a wide range of healthcare products and medicines to users. With its user-friendly interface and competitive pricing, Health Prime makes it easy for users to find and purchase the products they need. "
          }
          techStack={["Next.js", "Chakra UI", "FireBase", "Redux"]}
        />
      </Show>
    </Box>
  );
};

export default Projects;
